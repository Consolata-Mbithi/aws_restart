
#first code
print("Hello World")
