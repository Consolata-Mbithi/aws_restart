#Creating a car inventory data
