#Defining a list
myFruitList = ["Apple", "Bananas","Cherry" ,"Strawberries"]
print(myFruitList)
print(type(myFruitList))

#Accessing a list by position
print(myFruitList[0])

print(myFruitList[1])

print(myFruitList[2])

print(myFruitList[3])

#Changing the values in a list
myFruitList[2] = "Orange"

myFruitList[3] = "Dragon fruit"

print(myFruitList)

#the tuple data type
#The tuple is like a list, but it can't be changed
myFinalAnswerTuple = ("Apple" ,"banana", "Pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

#Accessing a tuple by position
print(myFinalAnswerTuple[0])

print(myFinalAnswerTuple[1])

print(myFinalAnswerTuple[2])

#dictionary data type
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}

print(myFavoriteFruitDictionary)

#Accessing a dictionary by name

print(myFavoriteFruitDictionary["Akua"])

print(myFavoriteFruitDictionary["Saanvi"])

print(myFavoriteFruitDictionary["Paulo"])