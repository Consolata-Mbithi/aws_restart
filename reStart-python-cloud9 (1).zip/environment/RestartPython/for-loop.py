print("Count to 10 !")

#for loop
for x in range (0,11):
    
    #output displays
    # x acts as a variable,Each time through the loop, the variable x is assigned to the 
    #next variable in the loop and is printed out to the screen
    print(x)