#numeric data types 
print("Python has three numeric types:int,float and complex")

#creating variables 
myValue=1

#printing the value on th screen
print(myValue)

#data type of the variable, using type built-in function
print(type(myValue))

#combine numbers and text, use the str() built-in function
print(str(myValue) + " is of the data type " + str(type(myValue)))

#float data type
myValue=3.14
#print the value on the screen
print(myValue)

#Get the data type
print(type(myValue))

#combine numbers and text, use the str() built-in function
print(str(myValue) + " is of data type " + str(type(myValue)))

#complex data type
myValue=5j

#print on the screen
print(myValue)

#get the data type
print(type(myValue))

#combine numbers and text, use the str() built-in function
print(str(myValue) + " is of the data type " + str(type(myValue)))

# bool data type
myValue=True

#get the data type
print(type(myValue))

#combine numbers and text ,use the str built in function
print(str(myValue) +  " is of the data type " + str(type(myValue)))

#declare the variable
myValue=False

##get the data type
print(type(myValue))

#combine numbers and text ,use the str built in function
print(str(myValue) + " is of the data type " + str(type(myValue)))

