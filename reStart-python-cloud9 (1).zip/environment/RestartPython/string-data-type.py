
#string data type
myString = " This is my string "

print(myString)

#get the data type of the variable
print(type(myString))

#return value of type into a string
print(myString + " is of the data type " + str(type(myString)))

#Working with string concatenation
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)

#Working with input strings
name = input ( "What is Your name" )
print(name)

#Formatting output strings
color = input(" What is your favourite color? ")
animal = input(" What is your favourite animal? ")

#use imultiple variables to format a string
print("{}, you like a {} {}!".format(name,color,animal))